package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// =========================================================================
// MASTER COLOR SYSTEM — "Crimson Obsidian Glassmorphism"
// Deep dark cinematic background (#070709, #0F0F14), glassmorphism UI,
// deep crimson + bright red accents, soft red glow, high-contrast white text.
// =========================================================================

// Master Red & Crimson Palette
val CrimsonRed = Color(0xFFE50914)        // Master Netflix/OTT Crimson Red
val DeepCrimson = Color(0xFFB71C1C)       // Deep rich ruby crimson
val BrightRedAccent = Color(0xFFFF2E4D)   // Vibrant glowing red accent
val NeonRed = Color(0xFFFF1744)           // Ultra bright neon red
val DarkRuby = Color(0xFF800A0E)          // Deep dark ruby base
val ElectricCoral = Color(0xFFFF4D67)     // Soft red coral highlight
val SoftRedGlow = Color(0xFFFF3355)       // Soft ambient red glow

// Backgrounds (Near-Black & Obsidian)
val MidnightBlack = Color(0xFF070709)     // Ultra deep pitch black
val DarkCharcoalBg = Color(0xFF0F0F14)    // Near-black charcoal canvas
val DeepRedBlackBg = Color(0xFF140D10)    // Deep subtle crimson-tinted black
val SlateDarkBg = Color(0xFF121217)       // Sleek dark surface
val DarkNavyBg = Color(0xFF0F0F14)        // Remapped to dark charcoal black
val DeepIndigoBg = Color(0xFF161217)      // Remapped to deep obsidian

// Translucent Glass Surfaces
val GlassSurfaceDark = Color(0xCC13131A)       // 80% opacity dark obsidian glass
val GlassSurfaceSubtle = Color(0x66181822)     // 40% opacity subtle glass
val GlassCardBg = Color(0xB315151D)            // 70% opacity frosted dark glass
val GlassCardHover = Color(0xCC201317)         // Active/Hover glass card with crimson sheen
val GlassSurfaceLight = Color(0x1AFFFFFF)      // 10% translucent white highlight
val GlassSurfaceUltraLight = Color(0x0DFFFFFF) // 5% translucent white sheen

// Glass Borders & Outlines
val GlassCardBorder = Color(0x33E50914)        // Soft crimson border (20% opacity)
val GlassCardBorderRed = Color(0x66FF1744)     // Vibrant red glass border (40% opacity)
val GlassCardBorderCyan = Color(0x66FF2E4D)    // Remapped to bright red border
val GlassCardBorderHover = Color(0x99FF1744)   // Active bright red border
val GlassWhiteBorder = Color(0x2EFFFFFF)       // Soft translucent white highlight border
val GlassSoftBorder = Color(0x264A4A5A)        // Neutral slate border

// Semantic Accents & Ratings
val AmberRating = Color(0xFFFFB300)            // Golden amber star rating
val EmeraldGreen = Color(0xFF10B981)           // Success / Active green
val CoralRed = Color(0xFFFF2E4D)               // Alert / error red

// High-Contrast Typography (Crisp White & Light Gray for crystal clear readability)
val TextPrimary = Color(0xFFF8FAFC)            // Crisp off-white (100% readable)
val TextSecondary = Color(0xFFA1A5B0)          // Clean readable light gray
val TextMuted = Color(0xFF6E7380)              // Muted slate gray

// Backward Compatibility Aliases for components using legacy names
val NeonCyan = BrightRedAccent
val CyanAccent = ElectricCoral
val VibrantPurple = CrimsonRed
val NeonViolet = DeepCrimson
val DeepPurple = DarkRuby
val ElectricMagenta = NeonRed
val SoftPinkGlow = SoftRedGlow

// =========================================================================
// Red + Black Gradients, Scrims & Glow Brushes
// =========================================================================
val RedCrimsonGradient = Brush.linearGradient(
    colors = listOf(BrightRedAccent, CrimsonRed)
)

val RedButtonGradient = Brush.horizontalGradient(
    colors = listOf(DeepCrimson, CrimsonRed, BrightRedAccent)
)

val RedGlowGradient = Brush.radialGradient(
    colors = listOf(
        BrightRedAccent.copy(alpha = 0.40f),
        CrimsonRed.copy(alpha = 0.15f),
        Color.Transparent
    )
)

val MidnightRedBackground = Brush.verticalGradient(
    colors = listOf(
        DarkCharcoalBg,
        MidnightBlack,
        Color(0xFF050507)
    )
)

val HeroScrimGradient = Brush.verticalGradient(
    colors = listOf(
        Color.Transparent,
        Color(0x33070709),
        Color(0xB3070709),
        MidnightBlack
    )
)

val PosterScrimGradient = Brush.verticalGradient(
    colors = listOf(
        Color.Transparent,
        Color(0x33070709),
        Color(0xCC070709),
        Color(0xF5070709)
    )
)

val GlassBorderGradient = Brush.linearGradient(
    colors = listOf(
        Color.White.copy(alpha = 0.35f),
        CrimsonRed.copy(alpha = 0.70f),
        BrightRedAccent.copy(alpha = 0.80f),
        Color.White.copy(alpha = 0.10f)
    )
)

val GlassCardGradient = Brush.linearGradient(
    colors = listOf(
        Color(0xCC1C1518),
        Color(0x99121217)
    )
)

// Legacy Aliases for seamless integration across all screens
val PurpleCyanGradient = RedCrimsonGradient
val AuroraButtonGradient = RedButtonGradient
val AuroraGlowGradient = RedGlowGradient
val MidnightAuroraBackground = MidnightRedBackground



