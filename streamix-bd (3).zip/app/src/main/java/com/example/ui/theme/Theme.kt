package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val StreamixDarkColorScheme = darkColorScheme(
    primary = CrimsonRed,
    onPrimary = Color.White,
    primaryContainer = CrimsonRed.copy(alpha = 0.25f),
    onPrimaryContainer = BrightRedAccent,
    secondary = BrightRedAccent,
    onSecondary = Color.White,
    secondaryContainer = DeepRedBlackBg,
    onSecondaryContainer = TextPrimary,
    tertiary = NeonRed,
    onTertiary = Color.White,
    background = MidnightBlack,
    onBackground = TextPrimary,
    surface = DarkCharcoalBg,
    onSurface = TextPrimary,
    surfaceVariant = DeepIndigoBg,
    onSurfaceVariant = TextSecondary,
    outline = GlassCardBorder,
    outlineVariant = GlassCardBorderRed,
    error = BrightRedAccent,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    // Streamix BD is designed as a unified premium midnight glassmorphism experience
    MaterialTheme(
        colorScheme = StreamixDarkColorScheme,
        typography = Typography,
        content = content
    )
}

