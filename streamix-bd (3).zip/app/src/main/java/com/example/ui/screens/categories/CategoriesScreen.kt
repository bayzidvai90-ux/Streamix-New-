package com.example.ui.screens.categories

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ContentItem
import com.example.data.repository.StreamixRepository
import com.example.ui.components.CategoryPillRow
import com.example.ui.components.ContentPosterCard
import com.example.ui.components.StreamixFooter
import com.example.ui.theme.MidnightBlack
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun CategoriesScreen(
    repository: StreamixRepository,
    initialCategorySlug: String = "all",
    onContentClick: (ContentItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val categories by repository.getCategories().collectAsStateWithLifecycle(emptyList())
    val allContent by repository.getAllPublishedContent().collectAsStateWithLifecycle(emptyList())

    var selectedSlug by remember(initialCategorySlug) { mutableStateOf(initialCategorySlug) }

    val filteredContent = if (selectedSlug == "all") {
        allContent
    } else {
        allContent.filter {
            it.categorySlug.equals(selectedSlug, ignoreCase = true) ||
            it.type.equals(selectedSlug, ignoreCase = true) ||
            it.genre.contains(selectedSlug, ignoreCase = true)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBlack)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Explore Categories",
                color = TextPrimary,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Browse curated Bangladeshi entertainment genres",
                color = TextSecondary,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Category Chips
            CategoryPillRow(
                categories = categories,
                selectedCategorySlug = selectedSlug,
                onSelectCategory = { selectedSlug = it }
            )

            Spacer(modifier = Modifier.height(14.dp))

            if (allContent.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = NeonCyan)
                }
            } else if (filteredContent.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No content available in this category yet.",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .testTag("categories_grid"),
                    contentPadding = PaddingValues(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(filteredContent, key = { it.id }) { item ->
                        ContentPosterCard(
                            content = item,
                            onClick = { onContentClick(item) },
                            width = 110.dp
                        )
                    }
                }
            }

            StreamixFooter()
            Spacer(modifier = Modifier.height(60.dp))
        }
    }
}
