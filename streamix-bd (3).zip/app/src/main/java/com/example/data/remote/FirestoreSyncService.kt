package com.example.data.remote

import android.util.Log
import com.example.data.local.AnnouncementDao
import com.example.data.local.CategoryDao
import com.example.data.local.ContentDao
import com.example.data.local.ContentRequestDao
import com.example.data.local.EpisodeDao
import com.example.data.model.Announcement
import com.example.data.model.Category
import com.example.data.model.ContentItem
import com.example.data.model.ContentRequest
import com.example.data.model.Episode
import com.example.data.repository.SeedData
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * Handles real-time online synchronization between Firebase Firestore (online master)
 * and the local Room database (offline cache).
 */
class FirestoreSyncService(
    private val contentDao: ContentDao,
    private val episodeDao: EpisodeDao,
    private val categoryDao: CategoryDao,
    private val contentRequestDao: ContentRequestDao,
    private val announcementDao: AnnouncementDao,
    private val scope: CoroutineScope
) {
    companion object {
        private const val TAG = "FirestoreSyncService"
        private const val COLLECTION_CONTENT = "content_items"
        private const val COLLECTION_EPISODES = "episodes"
        private const val COLLECTION_CATEGORIES = "categories"
        private const val COLLECTION_REQUESTS = "content_requests"
        private const val COLLECTION_ANNOUNCEMENTS = "announcements"
    }

    private var contentListener: ListenerRegistration? = null
    private var episodeListener: ListenerRegistration? = null
    private var categoryListener: ListenerRegistration? = null
    private var requestListener: ListenerRegistration? = null
    private var announcementListener: ListenerRegistration? = null

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _isFirebaseAvailable = MutableStateFlow(false)
    val isFirebaseAvailable: StateFlow<Boolean> = _isFirebaseAvailable.asStateFlow()

    private val firestoreInstance: FirebaseFirestore? by lazy {
        try {
            val db = FirebaseFirestore.getInstance()
            try {
                val settings = FirebaseFirestoreSettings.Builder()
                    .setPersistenceEnabled(true)
                    .build()
                db.firestoreSettings = settings
            } catch (e: Exception) {
                Log.d(TAG, "Firestore settings note: ${e.message}")
            }
            _isFirebaseAvailable.value = true
            db
        } catch (e: Throwable) {
            Log.w(TAG, "Firebase Firestore is not initialized or google-services.json is pending: ${e.message}")
            _isFirebaseAvailable.value = false
            null
        }
    }

    /**
     * Start real-time Firestore listeners to keep Room database synced.
     */
    fun startSync() {
        val db = firestoreInstance ?: run {
            Log.i(TAG, "Firestore not available; running in local Room cache mode.")
            return
        }

        try {
            _isSyncing.value = true
            setupContentListener(db)
            setupEpisodeListener(db)
            setupCategoryListener(db)
            setupRequestListener(db)
            setupAnnouncementListener(db)
        } catch (e: Exception) {
            Log.e(TAG, "Error starting Firestore sync: ${e.message}", e)
            _isSyncing.value = false
        }
    }

    private fun setupContentListener(db: FirebaseFirestore) {
        contentListener?.remove()
        contentListener = db.collection(COLLECTION_CONTENT)
            .addSnapshotListener { snapshots, error ->
                if (error != null) {
                    Log.w(TAG, "Content sync listen failed: ${error.message}")
                    _isSyncing.value = false
                    return@addSnapshotListener
                }

                if (snapshots != null) {
                    scope.launch(Dispatchers.IO) {
                        try {
                            if (snapshots.isEmpty) {
                                // If remote is completely empty, seed initial content to Firestore so all users receive it
                                Log.i(TAG, "Remote Firestore content is empty. Seeding initial catalog to Firestore...")
                                contentDao.insertAllContent(SeedData.initialContent)
                                categoryDao.insertAllCategories(SeedData.categories)
                                episodeDao.insertAllEpisodes(SeedData.episodes)
                                seedInitialFirestoreData(db)
                                _isSyncing.value = false
                                return@launch
                            }

                            val itemsToInsert = mutableListOf<ContentItem>()
                            for (change in snapshots.documentChanges) {
                                val doc = change.document
                                when (change.type) {
                                    DocumentChange.Type.ADDED, DocumentChange.Type.MODIFIED -> {
                                        val item = docToContentItem(doc.id, doc.data)
                                        if (item != null) {
                                            itemsToInsert.add(item)
                                        }
                                    }
                                    DocumentChange.Type.REMOVED -> {
                                        contentDao.deleteContentById(doc.id)
                                        episodeDao.deleteEpisodesByContentId(doc.id)
                                    }
                                }
                            }

                            if (itemsToInsert.isNotEmpty()) {
                                contentDao.insertAllContent(itemsToInsert)
                            }
                            _isSyncing.value = false
                        } catch (e: Exception) {
                            Log.e(TAG, "Error processing content snapshots: ${e.message}", e)
                        }
                    }
                }
            }
    }

    private fun setupEpisodeListener(db: FirebaseFirestore) {
        episodeListener?.remove()
        episodeListener = db.collection(COLLECTION_EPISODES)
            .addSnapshotListener { snapshots, error ->
                if (error != null) {
                    Log.w(TAG, "Episode sync listen failed: ${error.message}")
                    return@addSnapshotListener
                }

                if (snapshots != null) {
                    scope.launch(Dispatchers.IO) {
                        try {
                            val episodesToInsert = mutableListOf<Episode>()
                            for (change in snapshots.documentChanges) {
                                val doc = change.document
                                when (change.type) {
                                    DocumentChange.Type.ADDED, DocumentChange.Type.MODIFIED -> {
                                        val ep = docToEpisode(doc.id, doc.data)
                                        if (ep != null) {
                                            episodesToInsert.add(ep)
                                        }
                                    }
                                    DocumentChange.Type.REMOVED -> {
                                        episodeDao.deleteEpisodeById(doc.id)
                                    }
                                }
                            }
                            if (episodesToInsert.isNotEmpty()) {
                                episodeDao.insertAllEpisodes(episodesToInsert)
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Error processing episode snapshots: ${e.message}", e)
                        }
                    }
                }
            }
    }

    private fun setupCategoryListener(db: FirebaseFirestore) {
        categoryListener?.remove()
        categoryListener = db.collection(COLLECTION_CATEGORIES)
            .addSnapshotListener { snapshots, error ->
                if (error != null) {
                    Log.w(TAG, "Category sync listen failed: ${error.message}")
                    return@addSnapshotListener
                }

                if (snapshots != null) {
                    scope.launch(Dispatchers.IO) {
                        try {
                            val categoriesToInsert = mutableListOf<Category>()
                            for (change in snapshots.documentChanges) {
                                val doc = change.document
                                when (change.type) {
                                    DocumentChange.Type.ADDED, DocumentChange.Type.MODIFIED -> {
                                        val cat = docToCategory(doc.id, doc.data)
                                        if (cat != null) {
                                            categoriesToInsert.add(cat)
                                        }
                                    }
                                    DocumentChange.Type.REMOVED -> {
                                        categoryDao.deleteCategoryById(doc.id)
                                    }
                                }
                            }
                            if (categoriesToInsert.isNotEmpty()) {
                                categoryDao.insertAllCategories(categoriesToInsert)
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Error processing category snapshots: ${e.message}", e)
                        }
                    }
                }
            }
    }

    private fun setupRequestListener(db: FirebaseFirestore) {
        requestListener?.remove()
        requestListener = db.collection(COLLECTION_REQUESTS)
            .addSnapshotListener { snapshots, error ->
                if (error != null) {
                    Log.w(TAG, "Request sync listen failed: ${error.message}")
                    return@addSnapshotListener
                }

                if (snapshots != null) {
                    scope.launch(Dispatchers.IO) {
                        try {
                            for (change in snapshots.documentChanges) {
                                val doc = change.document
                                when (change.type) {
                                    DocumentChange.Type.ADDED, DocumentChange.Type.MODIFIED -> {
                                        val req = docToContentRequest(doc.id, doc.data)
                                        if (req != null) {
                                            contentRequestDao.insertRequest(req)
                                        }
                                    }
                                    DocumentChange.Type.REMOVED -> {
                                        contentRequestDao.deleteRequest(doc.id)
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Error processing request snapshots: ${e.message}", e)
                        }
                    }
                }
            }
    }

    private fun setupAnnouncementListener(db: FirebaseFirestore) {
        announcementListener?.remove()
        announcementListener = db.collection(COLLECTION_ANNOUNCEMENTS)
            .addSnapshotListener { snapshots, error ->
                if (error != null) {
                    Log.w(TAG, "Announcement sync listen failed: ${error.message}")
                    return@addSnapshotListener
                }

                if (snapshots != null) {
                    scope.launch(Dispatchers.IO) {
                        try {
                            for (change in snapshots.documentChanges) {
                                val doc = change.document
                                when (change.type) {
                                    DocumentChange.Type.ADDED, DocumentChange.Type.MODIFIED -> {
                                        val ann = docToAnnouncement(doc.id, doc.data)
                                        if (ann != null) {
                                            announcementDao.insertAnnouncement(ann)
                                        }
                                    }
                                    DocumentChange.Type.REMOVED -> {
                                        announcementDao.deleteAnnouncementById(doc.id)
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Error processing announcement snapshots: ${e.message}", e)
                        }
                    }
                }
            }
    }

    /**
     * Seeds initial catalog data into Firestore if it was empty.
     */
    private suspend fun seedInitialFirestoreData(db: FirebaseFirestore) {
        try {
            val batch = db.batch()
            for (item in SeedData.initialContent) {
                val docRef = db.collection(COLLECTION_CONTENT).document(item.id)
                batch.set(docRef, contentItemToMap(item), SetOptions.merge())
            }
            for (cat in SeedData.categories) {
                val docRef = db.collection(COLLECTION_CATEGORIES).document(cat.id)
                batch.set(docRef, categoryToMap(cat), SetOptions.merge())
            }
            for (ep in SeedData.episodes) {
                val docRef = db.collection(COLLECTION_EPISODES).document(ep.id)
                batch.set(docRef, episodeToMap(ep), SetOptions.merge())
            }
            for (ann in SeedData.sampleAnnouncements) {
                val docRef = db.collection(COLLECTION_ANNOUNCEMENTS).document(ann.id)
                batch.set(docRef, announcementToMap(ann), SetOptions.merge())
            }
            batch.commit().await()
            Log.i(TAG, "Initial catalog seeded to Firestore successfully.")
        } catch (e: Exception) {
            Log.w(TAG, "Failed to seed initial Firestore data: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // Content CRUD Operations
    // -------------------------------------------------------------
    suspend fun saveContentItem(item: ContentItem, episodesList: List<Episode> = emptyList()) {
        withContext(Dispatchers.IO) {
            // 1. Update local Room cache immediately
            contentDao.insertContent(item)
            if (item.type == "SERIES" && episodesList.isNotEmpty()) {
                episodeDao.insertAllEpisodes(episodesList)
            }

            // 2. Sync to Firebase Firestore
            val db = firestoreInstance ?: return@withContext
            try {
                val batch = db.batch()
                val itemRef = db.collection(COLLECTION_CONTENT).document(item.id)
                batch.set(itemRef, contentItemToMap(item), SetOptions.merge())

                if (item.type == "SERIES" && episodesList.isNotEmpty()) {
                    for (ep in episodesList) {
                        val epRef = db.collection(COLLECTION_EPISODES).document(ep.id)
                        batch.set(epRef, episodeToMap(ep), SetOptions.merge())
                    }
                }
                batch.commit().await()
                Log.d(TAG, "ContentItem ${item.id} saved to Firestore successfully.")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to save ContentItem to Firestore: ${e.message}", e)
            }
        }
    }

    suspend fun deleteContentItem(contentId: String) {
        withContext(Dispatchers.IO) {
            // 1. Delete from local Room cache immediately
            episodeDao.deleteEpisodesByContentId(contentId)
            contentDao.deleteContentById(contentId)

            // 2. Delete from Firebase Firestore
            val db = firestoreInstance ?: return@withContext
            try {
                db.collection(COLLECTION_CONTENT).document(contentId).delete().await()

                // Delete associated episodes in Firestore
                val epDocs = db.collection(COLLECTION_EPISODES)
                    .whereEqualTo("contentId", contentId)
                    .get()
                    .await()

                if (!epDocs.isEmpty) {
                    val batch = db.batch()
                    for (doc in epDocs.documents) {
                        batch.delete(doc.reference)
                    }
                    batch.commit().await()
                }
                Log.d(TAG, "ContentItem $contentId deleted from Firestore.")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to delete ContentItem from Firestore: ${e.message}", e)
            }
        }
    }

    suspend fun updateContentField(contentId: String, field: String, value: Any) {
        withContext(Dispatchers.IO) {
            val db = firestoreInstance ?: return@withContext
            try {
                db.collection(COLLECTION_CONTENT).document(contentId).update(field, value).await()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to update field $field on $contentId in Firestore: ${e.message}", e)
            }
        }
    }

    // -------------------------------------------------------------
    // Category Operations
    // -------------------------------------------------------------
    suspend fun saveCategory(category: Category) {
        withContext(Dispatchers.IO) {
            categoryDao.insertCategory(category)
            val db = firestoreInstance ?: return@withContext
            try {
                db.collection(COLLECTION_CATEGORIES).document(category.id)
                    .set(categoryToMap(category), SetOptions.merge())
                    .await()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to save Category to Firestore: ${e.message}", e)
            }
        }
    }

    suspend fun deleteCategory(categoryId: String) {
        withContext(Dispatchers.IO) {
            categoryDao.deleteCategoryById(categoryId)
            val db = firestoreInstance ?: return@withContext
            try {
                db.collection(COLLECTION_CATEGORIES).document(categoryId).delete().await()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to delete Category from Firestore: ${e.message}", e)
            }
        }
    }

    // -------------------------------------------------------------
    // Content Requests
    // -------------------------------------------------------------
    suspend fun submitContentRequest(request: ContentRequest) {
        withContext(Dispatchers.IO) {
            contentRequestDao.insertRequest(request)
            val db = firestoreInstance ?: return@withContext
            try {
                db.collection(COLLECTION_REQUESTS).document(request.id)
                    .set(contentRequestToMap(request), SetOptions.merge())
                    .await()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to submit ContentRequest to Firestore: ${e.message}", e)
            }
        }
    }

    suspend fun updateRequestStatus(requestId: String, status: String, adminFeedback: String) {
        withContext(Dispatchers.IO) {
            contentRequestDao.updateRequestStatus(requestId, status, adminFeedback)
            val db = firestoreInstance ?: return@withContext
            try {
                db.collection(COLLECTION_REQUESTS).document(requestId).update(
                    mapOf(
                        "status" to status,
                        "adminFeedback" to adminFeedback
                    )
                ).await()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to update request in Firestore: ${e.message}", e)
            }
        }
    }

    suspend fun deleteRequest(requestId: String) {
        withContext(Dispatchers.IO) {
            contentRequestDao.deleteRequest(requestId)
            val db = firestoreInstance ?: return@withContext
            try {
                db.collection(COLLECTION_REQUESTS).document(requestId).delete().await()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to delete request in Firestore: ${e.message}", e)
            }
        }
    }

    // -------------------------------------------------------------
    // Announcements Operations
    // -------------------------------------------------------------
    suspend fun saveAnnouncement(announcement: Announcement) {
        withContext(Dispatchers.IO) {
            // 1. Update local Room database immediately
            announcementDao.insertAnnouncement(announcement)

            // 2. Sync to Firebase Firestore
            val db = firestoreInstance ?: return@withContext
            try {
                db.collection(COLLECTION_ANNOUNCEMENTS).document(announcement.id)
                    .set(announcementToMap(announcement), SetOptions.merge())
                    .await()
                Log.d(TAG, "Announcement ${announcement.id} saved to Firestore successfully.")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to save Announcement to Firestore: ${e.message}", e)
            }
        }
    }

    suspend fun deleteAnnouncement(announcementId: String) {
        withContext(Dispatchers.IO) {
            // 1. Delete from local Room cache immediately
            announcementDao.deleteAnnouncementById(announcementId)

            // 2. Delete from Firebase Firestore
            val db = firestoreInstance ?: return@withContext
            try {
                db.collection(COLLECTION_ANNOUNCEMENTS).document(announcementId).delete().await()
                Log.d(TAG, "Announcement $announcementId deleted from Firestore.")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to delete Announcement from Firestore: ${e.message}", e)
            }
        }
    }

    suspend fun toggleAnnouncementStatus(announcementId: String, isActive: Boolean) {
        withContext(Dispatchers.IO) {
            announcementDao.toggleAnnouncementActive(announcementId, isActive)
            val db = firestoreInstance ?: return@withContext
            try {
                db.collection(COLLECTION_ANNOUNCEMENTS).document(announcementId)
                    .update("isActive", isActive)
                    .await()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to toggle announcement in Firestore: ${e.message}", e)
            }
        }
    }

    fun stopSync() {
        contentListener?.remove()
        episodeListener?.remove()
        categoryListener?.remove()
        requestListener?.remove()
        announcementListener?.remove()
        _isSyncing.value = false
    }

    // -------------------------------------------------------------
    // Mappers
    // -------------------------------------------------------------
    private fun contentItemToMap(item: ContentItem): Map<String, Any> {
        return mapOf(
            "id" to item.id,
            "title" to item.title,
            "type" to item.type,
            "description" to item.description,
            "genre" to item.genre,
            "language" to item.language,
            "releaseYear" to item.releaseYear,
            "durationMinutes" to item.durationMinutes,
            "rating" to item.rating,
            "posterUrl" to item.posterUrl,
            "backdropUrl" to item.backdropUrl,
            "videoUrl" to item.videoUrl,
            "trailerUrl" to item.trailerUrl,
            "isFeatured" to item.isFeatured,
            "isTrending" to item.isTrending,
            "isPopular" to item.isPopular,
            "isPublished" to item.isPublished,
            "viewsCount" to item.viewsCount,
            "categorySlug" to item.categorySlug,
            "castAndCrew" to item.castAndCrew,
            "tags" to item.tags
        )
    }

    private fun docToContentItem(id: String, data: Map<String, Any>?): ContentItem? {
        if (data == null) return null
        return try {
            ContentItem(
                id = (data["id"] as? String) ?: id,
                title = (data["title"] as? String) ?: "",
                type = (data["type"] as? String) ?: "MOVIE",
                description = (data["description"] as? String) ?: "",
                genre = (data["genre"] as? String) ?: "Drama",
                language = (data["language"] as? String) ?: "Bengali",
                releaseYear = (data["releaseYear"] as? Number)?.toInt() ?: 2024,
                durationMinutes = (data["durationMinutes"] as? Number)?.toInt() ?: 120,
                rating = (data["rating"] as? Number)?.toDouble() ?: 4.5,
                posterUrl = (data["posterUrl"] as? String) ?: "",
                backdropUrl = (data["backdropUrl"] as? String) ?: "",
                videoUrl = (data["videoUrl"] as? String) ?: "",
                trailerUrl = (data["trailerUrl"] as? String) ?: "",
                isFeatured = (data["isFeatured"] as? Boolean) ?: false,
                isTrending = (data["isTrending"] as? Boolean) ?: false,
                isPopular = (data["isPopular"] as? Boolean) ?: false,
                isPublished = (data["isPublished"] as? Boolean) ?: true,
                viewsCount = (data["viewsCount"] as? Number)?.toInt() ?: 0,
                categorySlug = (data["categorySlug"] as? String) ?: "all",
                castAndCrew = (data["castAndCrew"] as? String) ?: "",
                tags = (data["tags"] as? String) ?: ""
            )
        } catch (e: Exception) {
            Log.w(TAG, "Error parsing ContentItem doc: ${e.message}")
            null
        }
    }

    private fun episodeToMap(ep: Episode): Map<String, Any> {
        return mapOf(
            "id" to ep.id,
            "contentId" to ep.contentId,
            "seasonNumber" to ep.seasonNumber,
            "episodeNumber" to ep.episodeNumber,
            "title" to ep.title,
            "durationMinutes" to ep.durationMinutes,
            "videoUrl" to ep.videoUrl,
            "thumbnailUrl" to ep.thumbnailUrl,
            "description" to ep.description
        )
    }

    private fun docToEpisode(id: String, data: Map<String, Any>?): Episode? {
        if (data == null) return null
        return try {
            Episode(
                id = (data["id"] as? String) ?: id,
                contentId = (data["contentId"] as? String) ?: "",
                seasonNumber = (data["seasonNumber"] as? Number)?.toInt() ?: 1,
                episodeNumber = (data["episodeNumber"] as? Number)?.toInt() ?: 1,
                title = (data["title"] as? String) ?: "",
                durationMinutes = (data["durationMinutes"] as? Number)?.toInt() ?: 45,
                videoUrl = (data["videoUrl"] as? String) ?: "",
                thumbnailUrl = (data["thumbnailUrl"] as? String) ?: "",
                description = (data["description"] as? String) ?: ""
            )
        } catch (e: Exception) {
            Log.w(TAG, "Error parsing Episode doc: ${e.message}")
            null
        }
    }

    private fun categoryToMap(cat: Category): Map<String, Any> {
        return mapOf(
            "id" to cat.id,
            "name" to cat.name,
            "slug" to cat.slug,
            "iconName" to cat.iconName,
            "displayOrder" to cat.displayOrder
        )
    }

    private fun docToCategory(id: String, data: Map<String, Any>?): Category? {
        if (data == null) return null
        return try {
            Category(
                id = (data["id"] as? String) ?: id,
                name = (data["name"] as? String) ?: "",
                slug = (data["slug"] as? String) ?: "",
                iconName = (data["iconName"] as? String) ?: "Movie",
                displayOrder = (data["displayOrder"] as? Number)?.toInt() ?: 0
            )
        } catch (e: Exception) {
            Log.w(TAG, "Error parsing Category doc: ${e.message}")
            null
        }
    }

    private fun contentRequestToMap(req: ContentRequest): Map<String, Any> {
        return mapOf(
            "id" to req.id,
            "title" to req.title,
            "contentType" to req.contentType,
            "requestedByUserId" to req.requestedByUserId,
            "requestedByUsername" to req.requestedByUsername,
            "description" to req.description,
            "status" to req.status,
            "submittedAt" to req.submittedAt,
            "adminFeedback" to req.adminFeedback
        )
    }

    private fun docToContentRequest(id: String, data: Map<String, Any>?): ContentRequest? {
        if (data == null) return null
        return try {
            ContentRequest(
                id = (data["id"] as? String) ?: id,
                title = (data["title"] as? String) ?: "",
                contentType = (data["contentType"] as? String) ?: "MOVIE",
                requestedByUserId = (data["requestedByUserId"] as? String) ?: "",
                requestedByUsername = (data["requestedByUsername"] as? String) ?: "",
                description = (data["description"] as? String) ?: "",
                status = (data["status"] as? String) ?: "PENDING",
                submittedAt = (data["submittedAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                adminFeedback = (data["adminFeedback"] as? String) ?: ""
            )
        } catch (e: Exception) {
            Log.w(TAG, "Error parsing ContentRequest doc: ${e.message}")
            null
        }
    }

    private fun announcementToMap(ann: Announcement): Map<String, Any> {
        return mapOf(
            "id" to ann.id,
            "title" to ann.title,
            "message" to ann.message,
            "imageUrl" to ann.imageUrl,
            "isActive" to ann.isActive,
            "createdAt" to ann.createdAt,
            "authorName" to ann.authorName
        )
    }

    private fun docToAnnouncement(id: String, data: Map<String, Any>?): Announcement? {
        if (data == null) return null
        return try {
            Announcement(
                id = (data["id"] as? String) ?: id,
                title = (data["title"] as? String) ?: "",
                message = (data["message"] as? String) ?: "",
                imageUrl = (data["imageUrl"] as? String) ?: "",
                isActive = (data["isActive"] as? Boolean) ?: true,
                createdAt = (data["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                authorName = (data["authorName"] as? String) ?: "Streamix Admin"
            )
        } catch (e: Exception) {
            Log.w(TAG, "Error parsing Announcement doc: ${e.message}")
            null
        }
    }
}
