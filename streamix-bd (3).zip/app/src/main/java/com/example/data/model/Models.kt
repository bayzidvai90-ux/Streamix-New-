package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ContentType(val displayName: String) {
    MOVIE("Movie"),
    NATOK("Natok"),
    FILM("Film"),
    SERIES("Series");

    companion object {
        fun fromString(value: String): ContentType {
            return entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: MOVIE
        }
    }
}

enum class RequestStatus(val displayName: String) {
    PENDING("Pending"),
    APPROVED("Approved"),
    REJECTED("Rejected"),
    COMPLETED("Completed");

    companion object {
        fun fromString(value: String): RequestStatus {
            return entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: PENDING
        }
    }
}

enum class DownloadStatus {
    DOWNLOADING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELED
}

@Entity(tableName = "users")
data class User(
    @PrimaryKey val id: String,
    val username: String,
    val email: String,
    val passwordHash: String,
    val fullName: String,
    val role: String = "USER", // "USER" or "ADMIN"
    val status: String = "ACTIVE", // "ACTIVE" or "SUSPENDED"
    val avatarUrl: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val totalWatchTimeMinutes: Int = 0,
    val totalDownloads: Int = 0
)

@Entity(tableName = "content_items")
data class ContentItem(
    @PrimaryKey val id: String,
    val title: String,
    val type: String, // MOVIE, NATOK, FILM, SERIES
    val description: String,
    val genre: String,
    val language: String = "Bengali",
    val releaseYear: Int = 2024,
    val durationMinutes: Int = 120,
    val rating: Double = 4.8,
    val posterUrl: String,
    val backdropUrl: String,
    val videoUrl: String,
    val trailerUrl: String = "",
    val isFeatured: Boolean = false,
    val isTrending: Boolean = false,
    val isPopular: Boolean = false,
    val isPublished: Boolean = true,
    val viewsCount: Int = 0,
    val categorySlug: String = "all",
    val castAndCrew: String = "",
    val tags: String = ""
)

@Entity(tableName = "episodes")
data class Episode(
    @PrimaryKey val id: String,
    val contentId: String,
    val seasonNumber: Int = 1,
    val episodeNumber: Int,
    val title: String,
    val durationMinutes: Int = 45,
    val videoUrl: String,
    val thumbnailUrl: String = "",
    val description: String = ""
)

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey val id: String,
    val name: String,
    val slug: String,
    val iconName: String = "Movie",
    val displayOrder: Int = 0
)

@Entity(tableName = "content_requests")
data class ContentRequest(
    @PrimaryKey val id: String,
    val title: String,
    val contentType: String,
    val requestedByUserId: String,
    val requestedByUsername: String,
    val description: String = "",
    val status: String = "PENDING", // PENDING, APPROVED, REJECTED, COMPLETED
    val submittedAt: Long = System.currentTimeMillis(),
    val adminFeedback: String = ""
)

@Entity(tableName = "saved_items", primaryKeys = ["userId", "contentId"])
data class SavedItem(
    val userId: String,
    val contentId: String,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "watch_history", primaryKeys = ["userId", "contentId", "episodeId"])
data class WatchHistory(
    val userId: String,
    val contentId: String,
    val episodeId: String = "",
    val watchedSeconds: Long = 0L,
    val totalDurationSeconds: Long = 0L,
    val lastWatchedAt: Long = System.currentTimeMillis(),
    val completed: Boolean = false
)

@Entity(tableName = "downloads")
data class DownloadItem(
    @PrimaryKey val id: String,
    val userId: String,
    val contentId: String,
    val episodeId: String = "",
    val title: String,
    val contentType: String,
    val filePath: String,
    val fileSizeMb: Double,
    val progress: Float = 0f,
    val status: String = "DOWNLOADING", // DOWNLOADING, PAUSED, COMPLETED, FAILED, CANCELED
    val quality: String = "1080p Full HD",
    val thumbnailUrl: String = "",
    val downloadedAt: Long = System.currentTimeMillis()
)

data class DashboardStats(
    val totalUsers: Int = 0,
    val activeUsers: Int = 0,
    val totalMovies: Int = 0,
    val totalSeries: Int = 0,
    val totalNatok: Int = 0,
    val totalFilms: Int = 0,
    val totalVideos: Int = 0,
    val totalViews: Long = 0L,
    val totalDownloads: Int = 0,
    val pendingRequests: Int = 0,
    val totalAnnouncements: Int = 0,
    val activeAnnouncements: Int = 0
)

@Entity(tableName = "announcements")
data class Announcement(
    @PrimaryKey val id: String,
    val title: String,
    val message: String,
    val imageUrl: String = "",
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val authorName: String = "Streamix Admin"
)

data class VideoQualityOption(
    val label: String,
    val resolution: String,
    val bitrate: String
)
